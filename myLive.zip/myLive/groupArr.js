var groupArr = [
    {
        "groupId": 0,
        "groupName": "北邮央视"
    },
    {
        "groupId": 1,
        "groupName": "北邮卫视"
    },
    {
        "groupId": 2,
        "groupName": "北邮高清"
    },
    {
        "groupId": 3,
        "groupName": "北邮北京"
    },
    {
        "groupId": 4,
        "groupName": "儿童动画"
    },
    {
        "groupId": 5,
        "groupName": "体育频道"
    },
    {
        "groupId": 6,
        "groupName": "CCTV-1备源"
    },
    {
        "groupId": 7,
        "groupName": "CCTV-2备源"
    },
    {
        "groupId": 8,
        "groupName": "CCTV-3备源"
    },
    {
        "groupId": 9,
        "groupName": "CCTV-4备源"
    },
    {
        "groupId": 10,
        "groupName": "CCTV-5备源"
    },
    {
        "groupId": 11,
        "groupName": "CCTV5+备源"
    },
    {
        "groupId": 12,
        "groupName": "CCTV-6备源"
    },
    {
        "groupId": 13,
        "groupName": "CCTV-7备源"
    },
    {
        "groupId": 14,
        "groupName": "CCTV-8备源"
    },
    {
        "groupId": 15,
        "groupName": "CCTV-9备源"
    },
    {
        "groupId": 16,
        "groupName": "CCTV-10备源"
    },
    {
        "groupId": 17,
        "groupName": "CCTV-11备源"
    },
    {
        "groupId": 18,
        "groupName": "CCTV-12备源"
    },
    {
        "groupId": 19,
        "groupName": "CCTV-13备源"
    },
    {
        "groupId": 20,
        "groupName": "CCTV-14备源"
    },
    {
        "groupId": 21,
        "groupName": "CCTV-15备源"
    },
    {
        "groupId": 22,
        "groupName": "央视出品"
    },
    {
        "groupId": 23,
        "groupName": "卫视备源"
    },
    {
        "groupId": 24,
        "groupName": "测试频道"
    },
    {
        "groupId": 25,
        "groupName": "江苏移动"
    },
    {
        "groupId": 26,
        "groupName": "影视荟萃"
    },
    {
        "groupId": 27,
        "groupName": "地方台"
    },
    {
        "groupId": 28,
        "groupName": "新添加"
    }
]